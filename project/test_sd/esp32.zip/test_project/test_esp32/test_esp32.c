﻿#include <stdio.h> 
#include <stdlib.h> 
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <malloc.h>
#include <sys/ioctl.h>
#include "ite/ith.h"
#include "ite/itp.h"
#include "ite/ite_esp32_sdio_at.h"

static void DoScan()
{
#define BUF_SIZE    (2048+1024)
    struct esp32_cmd at_cmd = { 0 };
    struct esp32_data data= { 0 };
    int rc;

    strcpy(at_cmd.cmd_buf, "AT+CWLAP\r\n");
    at_cmd.flags = (ESP32_DATA_READ | ESP32_WAIT_ACK);
    at_cmd.timeout = 5000;
    data.buf = (uint8_t*)malloc(BUF_SIZE);
    memset((void*)data.buf, 0x0, BUF_SIZE);
    data.length = BUF_SIZE;
    data.header_len = 7;  // "+CWLAP:"
    at_cmd.data = (void*)&data;

    esp32_sdio_at_lock();
    rc = esp32_at_cmd(&at_cmd);
    esp32_sdio_at_unlock();
    if (rc)
        goto end;

    if (at_cmd.status)
        printf("scan status: %d \n", at_cmd.status);

    printf("%s \n", data.buf);

end:
    free(data.buf);
}

static void DoPing(struct esp32_cmd *at_cmd)
{
ping:
    strcpy(at_cmd->cmd_buf, "AT+PING=\"192.168.1.1\"\r\n");
    at_cmd->flags = ESP32_WAIT_ACK;
    at_cmd->timeout = 5000;
    esp32_sdio_at_lock();
    esp32_at_cmd(at_cmd);

    esp32_sdio_at_unlock();

    if (at_cmd->status) {
        printf("ping error!! \n");
        usleep(3 * 1000 * 1000);
    }
    goto ping;

}

//#define WRITE_TO_FILE

#if defined(WRITE_TO_FILE)

#define HTTP_BUF_SIZE   64*1024

struct http_download_buf {
    uint8_t *buf;
    uint32_t data_len;
    sem_t   sem_to_write;  // data ready to write
    sem_t   sem_to_read;  // buffer ready to read data
};

struct http_ctxt {
    struct http_download_buf buf[2];
    pthread_t thread;
    sem_t     sem_init;
    uint32_t  file_size;
};

static struct http_ctxt g_http;

static void* download_write(void *arg)
{
    int w_index = 0, rc;
    struct http_ctxt *http = (struct http_ctxt*)arg;
    struct http_download_buf *hbuf = http->buf;
    FILE *file = NULL;
    uint32_t write_size = 0;

    /* init something here */
    hbuf[0].buf = malloc(HTTP_BUF_SIZE);
    hbuf[1].buf = malloc(HTTP_BUF_SIZE);
    sem_init(&hbuf[0].sem_to_read, 0, 1);
    sem_init(&hbuf[1].sem_to_read, 0, 1);
    sem_init(&hbuf[0].sem_to_write, 0, 0);
    sem_init(&hbuf[1].sem_to_write, 0, 0);

    sem_post(&http->sem_init);

open_file:
    file = fopen("A:/test.rar", "wb");
    if (file == NULL) {
        printf("open A:/test.rar fail! \n\n");
        usleep(1000*1000);
        goto open_file;
    }
    printf("open A:/test.rar success! \n\n");

wait:
    rc = itpSemWaitTimeout(&hbuf[w_index].sem_to_write, 20*1000);
    if (rc){
        printf("http download wait to write timeout! w_index:%d \n", w_index);
        while (1);
    }
    //printf("ready to write: buf %d, size: %d \n", w_index, hbuf[w_index].data_len);
    printf("w%d_size:%d \n", w_index, hbuf[w_index].data_len);
    rc = fwrite(hbuf[w_index].buf, 1, hbuf[w_index].data_len, file);
    if (rc != hbuf[w_index].data_len) {
        printf("fwrite fail! w%d_size: %d, data_size: %d \n", w_index, rc, hbuf[w_index].data_len);
        while (1);
    }
    write_size += hbuf[w_index].data_len;
    if (write_size == http->file_size) {
        printf(" wirte file finish! \n");
        fclose(file);
        goto out;
    }
    sem_post(&hbuf[w_index].sem_to_read);
    w_index = !w_index;
    goto wait;

out:
    if (hbuf[0].buf) {
        free(hbuf[0].buf);
        hbuf[0].buf = NULL;
    }
    if (hbuf[1].buf) {
        free(hbuf[1].buf);
        hbuf[1].buf = NULL;
    }
    sem_destroy(&hbuf[0].sem_to_read);
    sem_destroy(&hbuf[1].sem_to_read);
    sem_destroy(&hbuf[0].sem_to_write);
    sem_destroy(&hbuf[1].sem_to_write);

    return NULL;
}

static void http_download_cb(uint8_t *buf, uint32_t len)
{
    struct http_ctxt *http = &g_http;
    struct http_download_buf *hbuf = http->buf;
    int rc;
    static int r_index;
    static uint32_t total_rsize;

    //printf("http_download_cb(%d, %d) \n", buf, len);
    if (!http->file_size) {
        uint8_t *len_start, *len_end;
        if ((len_start = strstr(buf, "Content-Length: ")) != NULL) {
            uint8_t c_len[10] = "";
            len_start += 16;
            len_end = strstr(len_start, "\r\n");
            memcpy(c_len, len_start, len_end - len_start);
            http->file_size = atoi(c_len);
            printf("file size: %d \n", http->file_size);
            r_index = 0;
            total_rsize = 0;
        }
        else {
            printf("can't find \"Content-Length\"");
            while (1);
        }
    }
    else {
        if (len > (HTTP_BUF_SIZE - hbuf[r_index].data_len)) {
            //printf("len %d > (%d - %d:%d) \n", len, HTTP_BUF_SIZE, r_index, hbuf[r_index].data_len);
            printf("r%d_size:%d \n", r_index, hbuf[r_index].data_len);
            sem_post(&hbuf[r_index].sem_to_write);
            r_index = !r_index;
            rc = itpSemWaitTimeout(&hbuf[r_index].sem_to_read, 10*1000);
            if (rc) {
                printf("wait read buffer timeout!! r_index:%d \n", r_index);
                while (1);
            }
            hbuf[r_index].data_len = 0;
            printf("r%d :0 \n", r_index);
        }
        memcpy((hbuf[r_index].buf + hbuf[r_index].data_len), buf, len);
        hbuf[r_index].data_len += len;
        //printf("buf: %d, data_len: %d \n", r_index, hbuf[r_index].data_len);

        total_rsize += len;
        if (total_rsize == http->file_size) {
            sem_post(&hbuf[r_index].sem_to_write);
            esp32_at_cmd_ipd_end();
        }
    }
}

#else //#if defined(WRITE_TO_FILE)

static sem_t sem_download_ready;

static void http_download_cb(uint8_t *buf, uint32_t len)
{
    static uint32_t file_size;
    static uint32_t total_rsize;
    static uint32_t cnt;

    if (!file_size) {
        uint8_t *len_start, *len_end;
        if ((len_start = strstr(buf, "Content-Length: ")) != NULL) {
            uint8_t c_len[10] = "";
            len_start += 16;
            len_end = strstr(len_start, "\r\n");
            memcpy(c_len, len_start, len_end - len_start);
            file_size = atoi(c_len);
            printf("file size: %d \n", file_size);
            total_rsize = 0;
            cnt = 0;
        }
        else {
            printf("can't find \"Content-Length\"");
            while (1);
        }
    }
    else {
        total_rsize += len;
        if ((cnt++ % 200) == 0)
            printf("read: %d \n", total_rsize);
        if (total_rsize == file_size) {
            printf("download finish! \n");
            esp32_at_cmd_ipd_end();
            file_size = 0;
            sem_post(&sem_download_ready);
        }
    }
}

#endif //#if defined(WRITE_TO_FILE)

static void DoHttpDownload(void)
{
    int rc;
    struct esp32_cmd at_cmd = { 0 };

#if defined(WRITE_TO_FILE)
    pthread_attr_t attr;
    struct sched_param param;

    g_http.file_size = 0;
    sem_init(&g_http.sem_init, 0, 0);
    pthread_attr_init(&attr);
    param.sched_priority = 4;
    pthread_attr_setschedparam(&attr, &param);
    pthread_create(&g_http.thread, &attr, download_write, &g_http);
    sem_wait(&g_http.sem_init);
    sem_destroy(&g_http.sem_init);
#else
    sem_init(&sem_download_ready, 0, 0);
#endif

    esp32_sdio_at_lock();

    strcpy(at_cmd.cmd_buf, "AT+CIPSTART=\"TCP\",\"192.168.1.100\",8080,10\r\n");
    at_cmd.flags = ESP32_WAIT_ACK;  // wait "OK" or "ERROR"
    at_cmd.timeout = 5000;
    rc = esp32_at_cmd(&at_cmd);
    if (rc || at_cmd.status) {
        printf("TCP start fail! \n");
        goto end;
    }

download:
    strcpy(at_cmd.cmd_buf, "AT+CIPSEND=26\r\n");  // next HTTP cmd's length
    at_cmd.flags = ESP32_WAIT_FOR_SEND;  // wait '>'
    esp32_at_cmd(&at_cmd);

    /* 
       It will return:
       +IPD,324:HTTP/1.1 200 OK
       Content-Type: application/octet-stream
       Content-Length: 56268228
       Accept-Ranges: bytes
       Server: HFS 2.3m
       Set-Cookie: HFS_SID_=0.480718132574111; path=/; HttpOnly
       ETag: 6B790226D4090AA0EFADF56707EF27FA
       Last-Modified: Thu, 16 Jun 2016 02:08:49 GMT
       Content-Disposition: attachment; filename="test.rar";
    */
    strcpy(at_cmd.cmd_buf, "GET /test.rar HTTP/1.1\r\n\r\n");
    at_cmd.flags = ESP32_WAIT_ACK;  // wait "SEND OK"
    at_cmd.ipd_cb = http_download_cb;
    esp32_at_cmd(&at_cmd);

#if defined(WRITE_TO_FILE)
    pthread_join(g_http.thread, NULL);
    printf(" http thread join OK! \n");
#else
    sem_wait(&sem_download_ready);
    #if 1
    sem_destroy(&sem_download_ready);
    #else
    goto download;
    #endif
#endif

    strcpy(at_cmd.cmd_buf, "AT+CIPCLOSE\r\n");
    at_cmd.flags = ESP32_WAIT_ACK;  // wait OK
    esp32_at_cmd(&at_cmd);

end:
    esp32_sdio_at_unlock();
}

void DoUdp(void)
{
#define UDP_BUF_SIZE    2048
#define TEST_UDP_CNT    10000
    int rc, i;
    struct esp32_cmd at_cmd = { 0 };
    struct esp32_data data = { 0 };

    printf("\n\n======== DoUdp ==========\n\n");

    esp32_sdio_at_lock();

    strcpy(at_cmd.cmd_buf, "AT+CIPSTART=\"UDP\",\"192.168.1.100\",8080\r\n");
    at_cmd.flags = ESP32_WAIT_ACK;  // wait "OK" or "ERROR"
    rc = esp32_at_cmd(&at_cmd);
    if (rc || at_cmd.status) {
        printf("TCP start fail! rc:%d, at_cmd.status:%d \n", rc, at_cmd.status);
        goto end;
    }

    for (i = 0; i < TEST_UDP_CNT; i++) {
        strcpy(at_cmd.cmd_buf, "AT+CIPSEND=2048\r\n");
        at_cmd.flags = (ESP32_WAIT_FOR_SEND | ESP32_DATA_WRITE);  // wait '>'
        data.buf = malloc(UDP_BUF_SIZE); /* just send garbage */
        data.length = UDP_BUF_SIZE;
        at_cmd.data = &data;  /* one cmd with one data write */
        esp32_at_cmd(&at_cmd);
    }

    strcpy(at_cmd.cmd_buf, "AT+CIPCLOSE\r\n");
    at_cmd.flags = ESP32_WAIT_ACK;  // wait OK
    at_cmd.data = NULL;
    esp32_at_cmd(&at_cmd);

    esp32_sdio_at_unlock();
    printf("test UDP with write data ==> Done!! \n");

end:
    return;
}

void DoUdpPassThrough(void)
{
#define UDP_BUF_SIZE    4096
#define PASS_THROUGH_CNT    10000
    int rc, i;
    struct esp32_cmd at_cmd = { 0 };
    uint8_t *buf = NULL;

    esp32_sdio_at_lock();

    strcpy(at_cmd.cmd_buf, "AT+CIPSTART=\"UDP\",\"192.168.1.100\",8080\r\n");
    at_cmd.flags = ESP32_WAIT_ACK;  // wait "OK" or "ERROR"
    at_cmd.timeout = 5000;
    rc = esp32_at_cmd(&at_cmd);
    if (rc || at_cmd.status) {
        printf("TCP start fail! rc:%d, at_cmd.status:%d \n", rc, at_cmd.status);
        goto end;
    }
    at_cmd.timeout = 0;

    strcpy(at_cmd.cmd_buf, "AT+CIPMODE=1\r\n");
    at_cmd.flags = ESP32_WAIT_ACK;
    esp32_at_cmd(&at_cmd);

    strcpy(at_cmd.cmd_buf, "AT+CIPSEND\r\n");
    at_cmd.flags = ESP32_WAIT_FOR_SEND;  // wait '>'
    esp32_at_cmd(&at_cmd);

    buf = malloc(UDP_BUF_SIZE);
    at_cmd.flags = ESP32_DATA_WRITE;
    at_cmd.data = buf;
    at_cmd.cmd_len = UDP_BUF_SIZE; // data length for pass-through data write
    for (i = 0; i < PASS_THROUGH_CNT; i++) {
        esp32_at_cmd(&at_cmd);
        if ((i % 500) == 0)
            printf("cnt:%d \n", i);
    }
    printf("cnt:%d \n", i);

    strcpy(buf, "+++");
    at_cmd.flags = ESP32_DATA_WRITE;
    at_cmd.data = buf;
    at_cmd.cmd_len = 3; // data length for pass-through data write
    esp32_at_cmd(&at_cmd);
    at_cmd.data = NULL;
    at_cmd.cmd_len = 0;

    strcpy(at_cmd.cmd_buf, "AT+CIPMODE=0\r\n");
    at_cmd.flags = ESP32_WAIT_ACK;
    esp32_at_cmd(&at_cmd);

    strcpy(at_cmd.cmd_buf, "AT+CIPCLOSE\r\n");
    at_cmd.flags = ESP32_WAIT_ACK;  // wait OK
    esp32_at_cmd(&at_cmd);

    esp32_sdio_at_unlock();
    printf("test pass-through with UDP ==> Done!! \n");

end:
    return;
    //while (1);
}

void* TestFunc(void* arg)
{
    struct esp32_cmd at_cmd = { 0 };
    struct esp32_data data;
#define TEST_BUF_SIZE   128
    uint8_t buf[TEST_BUF_SIZE] = { 0 };
    static uint32_t loopcnt;

    itpInit();

    do {
        usleep(1000);
    } while (esp32_sdio_at_is_ready() == 0);

    esp32_sdio_at_lock();

    strcpy(at_cmd.cmd_buf, "AT+GMR\r\n");
    at_cmd.flags = ESP32_WAIT_ACK;
    esp32_at_cmd(&at_cmd);

    strcpy(at_cmd.cmd_buf, "AT+SYSRAM?\r\n");
    memset((void*)&data, 0x0, sizeof(struct esp32_data));
    at_cmd.flags = (ESP32_DATA_READ | ESP32_WAIT_ACK);
    data.buf = (uint8_t*)buf;
    memset((void*)data.buf, 0x0, TEST_BUF_SIZE);
    data.length = TEST_BUF_SIZE;
    data.header_len = 8;  // "+SYSRAM:"
    at_cmd.data = (void*)&data;
    esp32_at_cmd(&at_cmd);
    printf("%s \n", data.buf);

    strcpy(at_cmd.cmd_buf, "AT+CWMODE=1\r\n");
    at_cmd.flags = ESP32_WAIT_ACK;
    esp32_at_cmd(&at_cmd);

    strcpy(at_cmd.cmd_buf, "AT+CWMODE?\r\n");
    at_cmd.flags = ESP32_WAIT_ACK;
    esp32_at_cmd(&at_cmd);
#if 0
    strcpy(at_cmd.cmd_buf, "AT+CWJAP=\"irene_test\",\"12345678\"\r\n");
    at_cmd.flags = ESP32_WAIT_ACK;
    at_cmd.timeout = 10000;
    esp32_at_cmd(&at_cmd);
    if (at_cmd.status) {
        printf("join AP fail! \n");
        while (1);
    }
    at_cmd.timeout = 0; // use default timeout

    strcpy(at_cmd.cmd_buf, "AT+CIPSTATUS\r\n");
    at_cmd.flags = ESP32_WAIT_ACK;
    esp32_at_cmd(&at_cmd);

    strcpy(at_cmd.cmd_buf, "AT+CIPSTA=\"192.168.1.249\",\"192.168.1.254\",\"255.255.255.0\"\r\n");
    at_cmd.flags = ESP32_WAIT_ACK;
    esp32_at_cmd(&at_cmd);
#endif

    strcpy(at_cmd.cmd_buf, "AT+CIFSR\r\n");
    at_cmd.flags = ESP32_WAIT_ACK;
    esp32_at_cmd(&at_cmd);

    esp32_sdio_at_unlock();

    DoScan(&at_cmd);
    DoUdp();
    //DoPing(&at_cmd);
    //DoHttpDownload();
    //DoUdpPassThrough();
    //goto again;

    while (1) 
        sleep(1);
}

